<?php namespace Paymennt;


class Exception extends \Exception {};
