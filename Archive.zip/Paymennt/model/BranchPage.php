<?php namespace Paymennt\model;

/**
*  Branch class
*
*  A branch class representing a PAYMENNT search result of branch objects
*
*  @author abdullah
*/

class BranchPage{

  /**
  * array of branch objects
  * @var Branch
  */
  public $content=array();
  
}