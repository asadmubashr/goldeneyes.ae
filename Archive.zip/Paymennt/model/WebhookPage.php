<?php namespace Paymennt\model;

/**
*  Webhook class
*
*  A webhook class representing a PAYMENNT search result of webhook objects
*
*  @author bashar
*/

class WebhookPage{

  /**
  * array of webhook objects
  * @var Branch
  */
  public $content=array();
  
}