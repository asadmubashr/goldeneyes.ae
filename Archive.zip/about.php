
<?php 
$title = "About Us";
include "includes/header_head.php";
include "includes/header.php"
?>


<div class="section-container">
<?php include "widgets/aboutus/aboutus.php" ?>
</div>	

<div class="section-container">
    <?php include "widgets/home/company_stats_dark.php"?>
</div>
<div class="section-container">
<?php include "includes/footer.php" ?>
</div>
   