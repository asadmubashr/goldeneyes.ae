<?php 
$title = "Coworking";
include "../includes/header_head.php";
include "../includes/header.php";
?>

<section class="">
    <?php include "../widgets/co-working/co-working.php" ?>
</section>

<section class="">
    <?php include "../widgets/co-working/flexible-workspaces.php" ?>
</section>


<?php include "../includes/footer.php" ?>