<?php 
$title = "Contact Us";
include "../includes/header_head.php";
include "../includes/header.php"
?>

<div class="section-container">
    <?php include "../widgets/home/contact_widget.php"?>
    <hr style="margin: 0; padding: 0;">
</div>


<iframe
    src="https://www.google.com/maps/embed?pb=!1m23!1m12!1m3!1d115473.54242499715!2d55.2529020689923!3d25.252137937643045!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m8!3e6!4m0!4m5!1s0x3e5f5d3853ec4f93%3A0xbae9e8f70337b1c4!2sFifth%20Floor%2C%20Al%2C%20Etihad%20Building%20-%20Office%20No.%20504%20-%208th%20St%20-%20Deira%20-%20Dubai%20-%20United%20Arab%20Emirates!3m2!1d25.2521608!2d55.335303599999996!5e0!3m2!1sen!2s!4v1702720215343!5m2!1sen!2s"
    width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"
    referrerpolicy="no-referrer-when-downgrade"></iframe>
<?php include "../includes/footer.php" ?>