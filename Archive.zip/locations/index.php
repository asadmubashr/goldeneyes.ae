<?php 
$title = "Locations";
include "../includes/header_head.php";
include "../includes/header.php";
?>

<section class="">
    <?php include "../widgets/locations/locations.php" ?>
</section>


<?php include "../includes/footer.php" ?>