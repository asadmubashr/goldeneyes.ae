<?php 
$title = "Meeting Spaces";
include "../includes/header_head.php";
include "../includes/header.php";
?>

<section class="">
    <?php include "../widgets/meeting-spaces/premium-meeting-spaces.php" ?>
</section>

<section class="">
    <?php include "../widgets/meeting-spaces/versatile-layouts.php" ?>
</section>


<?php include "../includes/footer.php" ?>