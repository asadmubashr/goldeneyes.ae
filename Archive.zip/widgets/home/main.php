<div style="padding: 4em 0em; background-color: var(--background-color);">
    <div class="container">
        <div class="row">
            <div class="col-md-6 mb-5">
                <h2>Innovative Workspace</h2>
                <h3>Embark on Your Business</h3>
                <h3>Journey Here</h3>
                <div class="mt-4">
                    <a href="<?php echo $_ENV['ROOT_PATH'] ?>/contact-us"><button class="gradient-button">Book A Tour</button></a>
                </div>

            </div>
            <div class="col-md-6">
                <img src="<?php echo $_ENV['ROOT_PATH'] ?>/images/goldeneyes/1.jpg" alt=""
                    style="width: 100%; height: auto;">
            </div>
        </div>
    </div>
</div>