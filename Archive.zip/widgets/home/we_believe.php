<div class="we-believe">
    <div class="container">
        <div class="row d-flex justify-content-center">
            <span><b>"Where Innovation Meets Opportunity and Collaboration Drives Success."</b></span>
        </div>
    </div>
</div>

<style>
.we-believe {
    padding: 25px 0px;
}

.we-believe .row {
    text-align: center;
}

.we-believe span {
    color: var(--black-color);
    font-size: 24px;
    font-weight: bold;
}
</style>