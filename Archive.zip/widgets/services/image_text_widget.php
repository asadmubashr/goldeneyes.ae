<section class="ftco-section ftco-intro" style="padding: 4em 0em;">
    <div class="container px-md-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <!-- Image Column -->
                <div class="intro-img" style="background-image: url('<?php echo $_ENV['ROOT_PATH'];; ?>/images/najma/<?php echo $image; ?>'); height: 600px; width: 100%; background-size: cover; background-position: center; background-repeat: no-repeat;"></div>
            </div>
            <div class="col-md-6 text-center">
                <div class="heading-section ftco-animate">
                    <h2 class="mb-4" style="color: #1976d2;"><?php echo $title; ?></h2>
                </div>
                <p style="color: #000;" class="ftco-animate"><?php echo $description; ?></p>
            </div>
        </div>
    </div>
    </section>