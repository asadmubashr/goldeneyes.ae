<?php
$text = str_replace("Business Setup in Dubai", "<a href='#' style='color: #e65100;'>Business Setup in Dubai</a>", $text);
$text = str_replace("Business Setup in UAE", "<a href='#' style='color: #e65100;'>Business Setup in UAE</a>", $text);
$text = str_replace("business setup", "<a href='#' style='color: #e65100;'>business setup</a>", $text);

?>

<p style="color: rgb(50, 50, 50);"><?php echo $text?><p>
    