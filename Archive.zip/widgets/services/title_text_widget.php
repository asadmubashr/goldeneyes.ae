<?php
$description = str_replace("Business Setup", "<a href='#' style='color: #e65100;'>Business Setup</a>", $description);
?>
<h3 style="color: #262d55; "><?php echo $title ?></h3>
<p style="color: rgb(50, 50, 50);"><?php echo $description ?></p>